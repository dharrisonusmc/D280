import { style } from '@angular/animations';
import { Component, Input } from '@angular/core';
import { SvgMapComponent } from './svgmap/svgMap.component';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'worldMap';
  ctyName = ''

  constructor(private http: HttpClient) {}
  onSearch(ctyName){
      this.http.get('http://api.geonames.org/countryInfoJSON?username=dhar333')
      .pipe(map(responseData => {
        const dataArray = [];
        for (const key in responseData) {
          if (responseData.hasOwnProperty(key)){
          dataArray.push({...responseData[key], id: key})
        }
      }
      return dataArray;
      }))
      .subscribe(data => {
      let searchData = data[0]
      let i =0 
      for(i=0; i<=250; i++) {
        if (ctyName == searchData[i].countryName) {
          
        let countryName = searchData[i].countryName
        let countryCapitol = searchData[i].capital
        let countryRegion = searchData[i].continentName
        let countryPop = searchData[i].population
        let countryLong = searchData[i].west
        let countryLat = searchData[i].north
        let popField = 'Population:'
        const namep =document.getElementById("namep");
        namep.innerText = countryName
        const cap =document.getElementById("cap");
        cap.innerText = countryCapitol
        const reg =document.getElementById("reg");
        reg.innerText = countryRegion
        const pop =document.getElementById("pop");
        pop.innerText = popField
        const income =document.getElementById("income");
        income.innerText = countryPop
        const long =document.getElementById("long");
        long.innerText = countryLong
        const lat =document.getElementById("lat");
        lat.innerText = countryLat
        break;
        }
        }
        
      
      })
      
    };
 
  searchInput(event: Event) {
    this.ctyName = (<HTMLInputElement>event.target).value
  };
  

}





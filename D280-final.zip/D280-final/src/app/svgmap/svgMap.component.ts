import { Component } from '@angular/core';
import { AppComponent } from "src/app/app.component";

@Component({
  selector: 'app-svgMap',
  templateUrl: './svgMap.component.html',
  styleUrls: ['./svgMap.component.css']
})


export class SvgMapComponent {


  constructor() {}

  onClick() {
    document.querySelectorAll(".allPath").forEach(worldMap => {
      worldMap.addEventListener("click",function countryInfo(){
        
      async function getData(){
        const url= 'https://api.worldbank.org/V2/country/'+worldMap.id+'?format=json'
        const response = await fetch(url);
        const data = await response.json();
        const dataPath = data[1]
        let countryName = dataPath[0].name
        let countryCapitol = dataPath[0].capitalCity
        let countryRegion = dataPath[0].region.value
        let countryIncome = dataPath[0].incomeLevel.value
        let countryLong = dataPath[0].longitude
        let countryLat = dataPath[0].latitude
        let incomeField = 'Income:'
        const namep =document.getElementById("namep");
        namep.innerText = countryName
        const cap =document.getElementById("cap");
        cap.innerText = countryCapitol
        const reg =document.getElementById("reg");
        reg.innerText = countryRegion
        const pop =document.getElementById("pop");
        pop.innerText = incomeField
        const income =document.getElementById("income");
        income.innerText = countryIncome
        const long =document.getElementById("long");
        long.innerText = countryLong
        const lat =document.getElementById("lat");
        lat.innerText = countryLat
       
      }
      getData()
      
    })
    
  })
      
  }

  
}
 
